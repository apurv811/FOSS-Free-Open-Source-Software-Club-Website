	
	/*var TxtRotate = function(el, toRotate, period) {
		  this.toRotate = toRotate;
		  this.el = el;
		  this.loopNum = 0;
		  this.period = parseInt(period, 10) || 2000;
		  this.txt = '';
		  this.tick();
		  this.isDeleting = false;
	};

TxtRotate.prototype.tick = function() {
	  var i = this.loopNum % this.toRotate.length;
	  var fullTxt = this.toRotate[i];

	  if (this.isDeleting) {
	    this.txt = fullTxt.substring(0, this.txt.length - 1);
	  } else {
	    this.txt = fullTxt.substring(0, this.txt.length + 1);
 	  }

  this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

  var that = this;
  var delta = 250 - Math.random() * 200;

  if (this.isDeleting) { delta /= 2; }

  if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
  } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
  }

  setTimeout(function() {
    that.tick();
  }, delta);
};

*/
function run_timeline(){


	var t_data = Array(
		
		["Getting familiar with the cloud fundamentals" ,'10:45 AM  Onwards','18', ' JUNE', 'Prof. Chirag Patel','./posters/cc.png'],
		["Understanding the NullShell of JAVA",'8:45 AM  TO 1:30 PM','20-21', ' JUNE',' Mr. Dhiraj Poojara ','./posters/java.png'],
		["Introduction to Image Processing",'10:00 AM  TO 2:00 PM','22 ',' JUNE', 'Prof. Abhinay Pandya &  Ms. Hiral Parikh','./posters/ip.jpg'],
		
		["Introduction to Data Analytics",'9:30 AM  TO 3:00 PM','23 ',' JUNE', 'Mr. Nital Patwa, Mr. Amrith Krishna & Mr. Ritesh Sutaria','./posters/da.jpg'],
		["Programming Foundations with Python",'9:00 AM  TO 3:00 PM','24 - 25 ',' JUNE', 'Mr. Pankaj Kamani & Prof. Manisha Mehta  <br/> & Mr. Unni Krishnan','./posters/python.png'],
		//["Intro to Algorithms & Graph Theroy",'9:00 AM  TO 3:00 PM','26 ','JUNE', 'Prof. Mahesh Goyani','6.html'],
		
		["Introduction to Artificial Intelligence",'5:00 PM TO 7:00 PM ','29 ',' JUNE', 'Mr. Hemen Ashodia','./posters/ai.jpg'],
		
		["Workshop on Linux Device Driver", '3:00 PM(1st Day) & 9:30 AM(2nd Day) ','1 - 2','JULY' , 'Mr. Adarsh Parikh','./posters/apld.jpg'],
		//["Programming and Data Structure ",'9:00  AM TO 10:00 AM ','4-5','JULY', 'Prof. ','9.html'],
		["Introduction to Machine Learning ",'5:00 PM TO 7:00 PM ','5-6','JULY', 'Mr. Samkit Shah ','./posters/ml.png']
		
	);

	for( i in t_data){
// var t_dir = i%2 ==0 ?'l':'r';
		var t_thing = t_data[i][0];
		var t_time = t_data[i][3] + " " + t_data[i][2] + " <br> "+ t_data[i][1];
		var t_person = t_data[i][4];
		var t_img=t_data[i][5];

			var t_htm_data = '<li class="wow bounceInUp clickmod make-it-fast" href="'+t_img+'" > <h3>'+t_thing+'</h3> <h5><i> By '+t_person+'</i></h5><time>'+t_time+'</time> </li>';

			document.getElementById('tim_x').innerHTML+= t_htm_data;
	}
									  
}

function load_experts(){


var speak = Array(
[ 'Prof. Abhinay Pandya', ' Fundamentals Of Image Processing',' Head, I.T. Dept, LDRP Institute, Gandhinagar. Alumni, IIT-bombay. ' ,

 './speakers/abhinay_pandya.jpg' ,'https://www.linkedin.com/in/abhinay-pandya-1599b913'],
	
	[ 'Mr. Adarsh Parikh ',' Linux Device Driver',' Chief Operating Officer Teksun Group ',

	 './speakers/adarsh_parikh.jpg','https://www.linkedin.com/in/adarsh-parikh-31421494'],
	[ 'Mr. Amrith Krishna',' Fundamentals Of Data Analytics',' Research Scholar, Indian Institute Of Technology, Kharagpur ',

	 './speakers/amirath_krishna.jpg','http://www.amrithkrishna.com '],
	

	[ 'Prof. Chirag Patel',' Understanding The Cloud Computing Frameworks','Former Faculty Member LDCE. Head, IT Dept, Gec Modasa',

	 './speakers/chirag_patel.jpg','http://www.gecmodasa.ac.in/it/faculties.html'],
	
	[ 'Mr. Dhiraj Poojara',' Understanding The Nut-shell Of Java Language.',' Alumni 2005 Batch, Artistic Academician, Md, Royal Technosoft. ',
	 './speakers/dhiraj_poojara.jpg','https://in.linkedin.com/in/dhiraj-poojara-3241347b'],

	[ 'Mr. Hemen Ashodia',' Fundamental Research Work Over Data Structures',' Chief Scientist, F(x) Data Labs ',
	 './speakers/hemen_ashodia.jpg','https://www.linkedin.com/in/hemen-ashodia-01703730'],

	[ 'Mr.himanshu Patel',' Embedded System For Space Applications',' Alumni,2002 Batch,scientist At Space Application Centre(sac/isro) ',
	 './speakers/himanshu_patel.jpg','https://www.linkedin.com/in/HIMANSHU-PATEL-08054417'],

	['MS. HIRAL PARIKH','Application of Image Processing','SOFTWARE DEVELOPER, INDIAN SPACE RESEARCH ORGANIZATION',
	'./speakers/hiral_parikh.jpg','https://www.linkedin.com/in/hiral-parikh-93805883'],

	[ 'Dr. Keyur Sorathiya',' Human Computer Interaction',' Alumni,2006 Batch,asst. Prof. IIT Guwahati. ',
	 './speakers/keyur_sorathiya.jpg','https://www.linkedin.com/in/'],

	[ 'Prof. Nital Patwa',' Introduction To Data Science',' Alumni 1988 Batch,distinguished Engineer At Broadcom,san Fransisco Bay Area ',
	 './speakers/nital_patwa.jpg','https://www.linkedin.com/in/nitalpatwa'],

	[ 'Mr. Prashant Thakkar',' Intro. To Haddop & Map-reduce',' Ceo & Founder ,sculpsoft ',
	 './speakers/prashant_thakkar.jpg','https://www.linkedin.com/in/'],

	[ 'Mr. Ritesh Sutaria',' A Talk On Data Science',' Cto Prompt Softech ',
	 './speakers/ritesh_sutaria.jpg','https://www.linkedin.com/in/AADREJA'],
	
	// [ 'Mr. Samkit Shah',' Machine Learning Fundamentals',' Researcher, Indian Institute Of Technology, Bombay ',
	//  './speakers/samkit_shah.jpg','https://www.linkedin.com/in/samkit-shah-708ab381'],

	[ 'Mr. Samkit Shah',' Machine Learning Fundamentals',' Researcher, Indian Institute Of Technology, Bombay ',
	 './speakers/samkit_shah.jpg','https://www.linkedin.com/in/samkit-shah-708ab381']

	);

	
	var exp_list = document.getElementById('exp_list')
	for ( i in speak)
	{	

		var _mod = i%3;

		if( _mod == 0 ) {
			rawIncomplete = true;
			var newr = document.createElement('div');
			newr.className = "row";
		}

		fadeInx = _mod == 0 ? "fadeInLeft" : (_mod == 2 ? "fadeInRight" : "fadeInDown" );

		var s_htm = '<div class="col-sm-4 col-md-4 linkmex" data-href="'+speak[i][4]+'"><div class="wow '+fadeInx+'" data-wow-delay="0.2s"> <div class="service-box"><div class="service-icon" ><img class="cir_img" src="'+ speak[i][3] +'" style="background: grey; "/></div><div class="service-desc"><h5> '+ speak[i][0] +' </h5><h5 class="topic">'+speak[i][1]+'</h5><p>'+ speak[i][2] +' </p></div></div>';

		newr.innerHTML += s_htm; 

		if( _mod == 2 ){
			rawIncomplete = false;
			exp_list.appendChild(newr);
		}

	}
	if( rawIncomplete ){

		if( newr.childNodes.length == 1 ){
			newr.firstChild.className= "col-sm-12 col-md-12"
			
		}else if(newr.childNodes.length == 2){
			newr.firstChild.className= newr.childNodes[1].className= "col-sm-6 col-md-6";
			
		}
		// else if(newr.childNodes.length == 3){
		// 	newr.firstChild.className= "col-sm-4 col-md-4";
		// }
			exp_list.appendChild(newr);
	}


}

window.onload  = function(){

  // var elements = document.getElementsByClassName('txt-rotate');
  // for (var i=0; i<elements.length; i++) {
  //   var toRotate = elements[i].getAttribute('data-rotate');
  //   var period = elements[i].getAttribute('data-period');
  //   if (toRotate) {
  //     new TxtRotate(elements[i], JSON.parse(toRotate), period);
  //   }
  // }
  // // INJECT CSS
  // var css = document.createElement("style");
  // css.type = "text/css";
  // css.innerHTML = ".txt-rotate > .wrap { border-right: 0.08em solid #BBB;animation: blink .5s step-end infinite alternate; }";
  // document.body.appendChild(css);

};



(function ($) {
	load_experts();
	run_timeline();

	new WOW().init();


    $('html, body').animate({
        scrollTop: 0	
    }, 100);

	jQuery(window).load(function() { 
		jQuery("#preloader").delay(100).fadeOut("slow");
		jQuery("#load").delay(100).fadeOut("slow");
	});


	//jQuery to collapse the navbar on scroll
	$(window).scroll(function() {
		if ($(".navbar").offset().top > 50) {
			$(".navbar-fixed-top").addClass("top-nav-collapse");
		} else {
			$(".navbar-fixed-top").removeClass("top-nav-collapse");
		}
	});

	//jQuery for page scrolling feature - requires jQuery Easing plugin
	$(function() {
		$('.navbar-nav li a').bind('click', function(event) {
			var $anchor = $(this);
			$('html, body').stop().animate({
				scrollTop: $($anchor.attr('href')).offset().top
			}, 1500, 'easeInOutExpo');
			event.preventDefault();
		});
		$('.page-scroll a').bind('click', function(event) {
			var $anchor = $(this);
			$('html, body').stop().animate({
				scrollTop: $($anchor.attr('href')).offset().top
			}, 1500, 'easeInOutExpo');
			event.preventDefault();
		});
	});

	$(".linkmex").click(function(e){
		
		var newanc = document.createElement("a");
			// console.log(  $(this));
		newanc.setAttribute("href" , $(this).attr("data-href") );
		newanc.setAttribute("target","_blank");
		newanc.style = "display:none";
		body = document.getElementsByTagName('body')[0];
		body.appendChild(newanc);
				newanc.click();

	});



	$(".clickmod").fancybox();

})(jQuery);
