
	var TxtRotate = function(el, toRotate, period) {
		  this.toRotate = toRotate;
		  this.el = el;
		  this.loopNum = 0;
		  this.period = parseInt(period, 10) || 2000;
		  this.txt = '';
		  this.tick();
		  this.isDeleting = false;
	};

TxtRotate.prototype.tick = function() {
	  var i = this.loopNum % this.toRotate.length;
	  var fullTxt = this.toRotate[i];

	  if (this.isDeleting) {
	    this.txt = fullTxt.substring(0, this.txt.length - 1);
	  } else {
	    this.txt = fullTxt.substring(0, this.txt.length + 1);
 	  }

  this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

  var that = this;
  var delta = 250 - Math.random() * 200;

  if (this.isDeleting) { delta /= 2; }

  if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
  } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
  }

  setTimeout(function() {
    that.tick();
  }, delta);
};


function run_timeline(){

	var t_data = Array(
		
		["Getting familiar with the cloud fundamentals" ,'10:45 AM  Onwards','18', ' JUNE', 'Prof. Chirag Patel','/source code summer school/img/Summer School 2016 Posters/8.png'],
		["Understanding the NullShell of JAVA",'8:45 AM  TO 1:30 PM','20-21', ' JUNE',' Mr. Dhiraj Poojara ','/source code summer school/img/Summer School 2016 Posters/9.png'],
		["Introduction to Image Processing",'10:00 AM  TO 2:00 PM','22 ',' JUNE', 'Prof. Abhinay Pandya &  Ms. Hiral Parikh','/source code summer school/img/Summer School 2016 Posters/Prof_Pandya.jpg'],
		
		["Introduction to Data Analytics",'9:30 AM  TO 3:00 PM','23 ',' JUNE', 'Mr. Nital Patwa, Mr. Amrith Krishna & Mr. Ritesh Sutaria','/source code summer school/img/Summer School 2016 Posters/6.png'],
		["Programming Foundations with Python",'9:00 AM  TO 3:00 PM','24 - 25 ',' JUNE', 'Mr. Pankaj Kamani & Prof. Manisha Mehta  <br/> & Mr. Unni Krishnan','/source code summer school/img/Summer School 2016 Posters/Prof_Mehta.png'],
		//["Intro to Algorithms & Graph Theroy",'9:00 AM  TO 3:00 PM','26 ','JUNE', 'Prof. Mahesh Goyani','6.html'],
		
		["Introduction to Artificial Intelligence",'5:00 PM TO 7:00 PM ','29 ',' JUNE', 'Mr. Hemen Ashodia','/source code summer school/img/Summer School 2016 Posters/hemen Ashodia.jpg'],
		
		["Workshop on Linux Device Driver", '3:00 PM(1st Day) & 9:30 AM(2nd Day) ','1 - 2','JULY' , 'Mr. Adarsh Parikh','/source code summer school/img/Summer School 2016 Posters/Adarsh Parikh.jpg'],
		//["Programming and Data Structure ",'9:00  AM TO 10:00 AM ','4-5','JULY', 'Prof. ','9.html'],
		["Introduction to Machine Learning ",'5:00 PM TO 7:00 PM ','5-6','JULY', 'Mr. Samkit Shah ','/source code summer school/img/Summer School 2016 Posters/7.png']
		
	);

	for( i in t_data){

		// var t_dir = i%2 ==0 ?'l':'r';
		var t_thing = t_data[i][0];
		var t_time = t_data[i][1];
		var t_date = t_data[i][2];
		var t_mon=t_data[i][3];
		var t_person = t_data[i][4];
		var t_img=t_data[i][5];
		

 
			var t_htm_data = '<li class="wow bounceInUp"> <a href="'+t_img+'"> <h3>'+t_thing+'</h3 </a><h5><b> By '+t_person+'</b></h5> <h3>'+t_date+'<sup>th</sup> '+t_mon+'</h3>  <b> <u><time>' +t_time+'</time>  </b> </u></li>' ;

			document.getElementById('tim_x').innerHTML+= t_htm_data;
	}
									  
}
window.onload = function() {


	run_timeline();


  var elements = document.getElementsByClassName('txt-rotate');
  for (var i=0; i<elements.length; i++) {
    var toRotate = elements[i].getAttribute('data-rotate');
    var period = elements[i].getAttribute('data-period');
    if (toRotate) {
      new TxtRotate(elements[i], JSON.parse(toRotate), period);
    }
  }
  // INJECT CSS
  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = ".txt-rotate > .wrap { border-right: 0.08em solid #BBB;animation: blink .5s step-end infinite alternate; }";
  document.body.appendChild(css);
};